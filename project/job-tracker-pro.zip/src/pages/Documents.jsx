import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, FileCheck, Plus, X, Copy, Check, Tag, BarChart2, Upload, Download, Eye, Edit2, Trash2, Search, File, Clock, Calendar } from 'lucide-react';
import GlassCard from '../components/GlassCard';

// Initial sample resumes
const initialResumes = [
  { id: '1', name: 'Software Engineer - General', lastModified: '3 days ago', keywords: ['React', 'TypeScript', 'Node.js', 'AWS', 'Git'], content: 'Experienced software engineer with 5+ years in full-stack development...', created: '1 month ago', version: 'v3' },
  { id: '2', name: 'Frontend Specialist', lastModified: '1 week ago', keywords: ['React', 'Vue', 'CSS', 'UI/UX', 'JavaScript'], content: 'Frontend developer specializing in React and Vue.js...', created: '2 weeks ago', version: 'v2' },
  { id: '3', name: 'Full Stack Developer', lastModified: '2 weeks ago', keywords: ['Python', 'Django', 'React', 'PostgreSQL', 'Docker'], content: 'Full stack developer with experience in Python and JavaScript...', created: '3 weeks ago', version: 'v1' },
];

// Cover letter templates
const coverLetterTemplates = [
  { id: '1', name: 'Standard Application', preview: 'Dear Hiring Manager, I am excited to apply for the [Position] role at [Company]. With my background in [Field], I believe I would be a great fit...', fullText: 'Dear Hiring Manager,\n\nI am excited to apply for the [Position] role at [Company]. With my background in [Field] and [Number] years of experience, I believe I would be a great fit for your team.\n\nIn my previous role at [Previous Company], I [Achievement]. I am particularly drawn to [Company] because [Reason].\n\nI would love the opportunity to discuss how my skills can contribute to your team. Thank you for considering my application.\n\nBest regards,\n[Your Name]' },
  { id: '2', name: 'Startup Pitch', preview: 'Hi [Name], I have been following [Company] for a while and I am thrilled to apply...', fullText: 'Hi [Name],\n\nI have been following [Company] for a while and I am thrilled to apply for the [Position] role. Your mission to [Mission] really resonates with me.\n\nAs a [Current Role] at [Current Company], I have [Achievement]. I am excited about the opportunity to bring my skills to your team and help [Goal].\n\nI would love to chat about how I can contribute to [Company]`s continued growth.\n\nBest,\n[Your Name]' },
  { id: '3', name: 'Referral Mention', preview: 'Dear [Name], [Referrer Name] suggested I reach out about the [Position] role...', fullText: 'Dear [Name],\n\n[Referrer Name] suggested I reach out about the [Position] role at [Company]. They thought I would be a great fit given my experience with [Skill].\n\nI have [Number] years of experience in [Field], most recently at [Company] where I [Achievement]. I would love to bring this experience to [Company].\n\nThank you for considering my application. I look forward to hearing from you.\n\nBest regards,\n[Your Name]' },
  { id: '4', name: 'Career Change', preview: 'Dear Hiring Manager, I am writing to express my interest in transitioning to...', fullText: 'Dear Hiring Manager,\n\nI am writing to express my interest in the [Position] role at [Company]. After [Number] years in [Previous Field], I am excited to transition into [New Field].\n\nMy experience in [Previous Field] has given me valuable skills in [Transferable Skills]. I have also [Relevant Training/Certification/Project].\n\nI am eager to bring my unique perspective and skills to [Company]. Thank you for considering my application.\n\nBest regards,\n[Your Name]' },
];

const commonKeywords = {
  skills: ['JavaScript', 'React', 'Python', 'AWS', 'Docker', 'Git', 'SQL', 'Agile', 'REST API', 'TypeScript', 'Node.js', 'Vue', 'Angular', 'MongoDB', 'PostgreSQL', 'Kubernetes'],
  roles: ['Senior', 'Lead', 'Full Stack', 'Backend', 'Frontend', 'DevOps', 'Architect', 'Manager'],
  soft: ['Leadership', 'Communication', 'Team Player', 'Problem Solving', 'Mentorship', 'Collaboration'],
};

export default function Documents() {
  const [resumes, setResumes] = useState(initialResumes);
  const [selectedResume, setSelectedResume] = useState(null);
  const [isResumeModalOpen, setIsResumeModalOpen] = useState(false);
  const [isResumeDetailOpen, setIsResumeDetailOpen] = useState(false);
  const [isEditResumeOpen, setIsEditResumeOpen] = useState(false);
  const [isLetterModalOpen, setIsLetterModalOpen] = useState(false);
  const [selectedLetter, setSelectedLetter] = useState(null);
  const [editResume, setEditResume] = useState(null);
  const [newResume, setNewResume] = useState({ name: '', keywords: '', content: '', version: 'v1' });
  const [copiedLetter, setCopiedLetter] = useState(null);
  const [jobDescription, setJobDescription] = useState('');
  const [keywordScore, setKeywordScore] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Add new resume
  const handleAddResume = () => {
    if (!newResume.name) {
      alert('Please enter a resume name');
      return;
    }

    const resume = {
      id: Date.now().toString(),
      name: newResume.name,
      keywords: newResume.keywords.split(',').map(k => k.trim()).filter(k => k),
      content: newResume.content,
      lastModified: 'Just now',
      created: 'Just now',
      version: newResume.version
    };

    setResumes([...resumes, resume]);
    setNewResume({ name: '', keywords: '', content: '', version: 'v1' });
    setIsResumeModalOpen(false);
  };

  // Delete resume
  const handleDeleteResume = (id) => {
    if (confirm('Are you sure you want to delete this resume?')) {
      setResumes(resumes.filter((r) => r.id !== id));
      setIsResumeDetailOpen(false);
      setSelectedResume(null);
    }
  };

  // View resume details
  const handleViewResume = (resume) => {
    setSelectedResume(resume);
    setIsResumeDetailOpen(true);
  };

  // Edit resume
  const handleEditResume = (resume) => {
    setEditResume({ ...resume, keywordsStr: resume.keywords?.join(', ') || '' });
    setIsEditResumeOpen(true);
    setIsResumeDetailOpen(false);
  };

  // Save edited resume
  const handleSaveResume = () => {
    if (!editResume.name) {
      alert('Please enter a resume name');
      return;
    }

    setResumes(resumes.map((r) => {
      if (r.id === editResume.id) {
        return {
          ...editResume,
          keywords: editResume.keywordsStr.split(',').map(k => k.trim()).filter(k => k),
          lastModified: 'Just now'
        };
      }
      return r;
    }));

    setIsEditResumeOpen(false);
    setEditResume(null);
  };

  // Simulate upload file
  const handleUploadFile = () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.pdf,.doc,.docx,.txt';
    fileInput.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        const resume = {
          id: Date.now().toString(),
          name: file.name.replace(/\.[^/.]+$/, ''),
          keywords: [],
          content: 'Uploaded file content would appear here...',
          lastModified: 'Just now',
          created: 'Just now',
          version: 'v1'
        };
        setResumes([...resumes, resume]);
        alert(`File "${file.name}" uploaded successfully!`);
      }
    };
    fileInput.click();
  };

  // Copy cover letter
  const handleCopyLetter = (text, name) => {
    navigator.clipboard.writeText(text);
    setCopiedLetter(name);
    setTimeout(() => setCopiedLetter(null), 2000);
  };

  // View cover letter
  const handleViewLetter = (letter) => {
    setSelectedLetter(letter);
    setIsLetterModalOpen(true);
  };

  // Calculate keyword score
  const calculateKeywordScore = () => {
    if (!jobDescription.trim()) {
      alert('Please paste a job description first');
      return;
    }

    const jdLower = jobDescription.toLowerCase();
    const allKeywords = [...commonKeywords.skills, ...commonKeywords.roles, ...commonKeywords.soft];
    const found = [];
    const missing = [];

    allKeywords.forEach((keyword) => {
      if (jdLower.includes(keyword.toLowerCase())) {
        found.push(keyword);
      }
    });

    // Sample "your resume" keywords for demo
    const resumeKeywords = ['React', 'JavaScript', 'Python', 'AWS', 'Team Player', 'Problem Solving', 'Git', 'Agile'];
    resumeKeywords.forEach((keyword) => {
      if (!found.includes(keyword)) {
        missing.push(keyword);
      }
    });

    const uniqueJdKeywords = [...new Set(found)];
    const matchCount = resumeKeywords.filter((k) => uniqueJdKeywords.includes(k)).length;
    const score = Math.round((matchCount / resumeKeywords.length) * 100);

    setKeywordScore({ score, found: uniqueJdKeywords, missing: missing.slice(0, 5) });
  };

  // Filter resumes
  const filteredResumes = resumes.filter((resume) =>
    resume.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resume.keywords.some(k => k.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto"
    >
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">Documents</h1>
        <p className="text-gray-400">Organize your resumes and cover letters</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="p-4 rounded-lg bg-violet-500/20 border-glow">
          <p className="text-gray-400 text-sm">Resume Versions</p>
          <p className="text-2xl font-bold text-white">{resumes.length}</p>
        </div>
        <div className="p-4 rounded-lg bg-cyan-500/20 border-glow">
          <p className="text-gray-400 text-sm">Cover Templates</p>
          <p className="text-2xl font-bold text-white">{coverLetterTemplates.length}</p>
        </div>
        <div className="p-4 rounded-lg bg-green-500/20 border-glow">
          <p className="text-gray-400 text-sm">Unique Keywords</p>
          <p className="text-2xl font-bold text-white">{[...new Set(resumes.flatMap(r => r.keywords))].length}</p>
        </div>
        <div className="p-4 rounded-lg bg-yellow-500/20 border-glow">
          <p className="text-gray-400 text-sm">Last Updated</p>
          <p className="text-lg font-bold text-white">3 days ago</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Resume Versions */}
        <GlassCard delay={0.1}>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <FileCheck className="text-violet-400" size={20} /> My Resumes
            </h2>
            <div className="flex gap-2">
              <button
                onClick={handleUploadFile}
                className="btn-secondary px-4 py-2 rounded-lg text-white text-sm flex items-center gap-2"
              >
                <Upload size={16} /> Upload
              </button>
              <button
                onClick={() => setIsResumeModalOpen(true)}
                className="btn-primary px-4 py-2 rounded-lg text-white text-sm flex items-center gap-2"
              >
                <Plus size={16} /> Add Resume
              </button>
            </div>
          </div>

          {/* Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search resumes..."
                className="input-field w-full pl-10 py-2 rounded-lg text-white text-sm"
              />
            </div>
          </div>

          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {filteredResumes.map((resume, index) => (
              <motion.div
                key={resume.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + index * 0.05 }}
                className="p-4 bg-glass rounded-xl border border-white/5 hover:border-violet-500/30 transition-all group cursor-pointer"
                onClick={() => handleViewResume(resume)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg gradient-bg">
                      <FileText className="text-white" size={18} />
                    </div>
                    <div>
                      <h3 className="text-white font-medium">{resume.name}</h3>
                      <div className="flex items-center gap-2 text-gray-500 text-xs mt-1">
                        <Clock size={10} /> {resume.lastModified}
                        <span className="ml-2 px-2 py-0.5 bg-white/10 rounded">{resume.version}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => { e.stopPropagation(); handleEditResume(resume); }}
                      className="p-2 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-colors"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDeleteResume(resume.id); }}
                      className="p-2 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {resume.keywords.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {resume.keywords.slice(0, 5).map((keyword) => (
                      <span key={keyword} className="px-2 py-0.5 bg-violet-500/20 rounded text-violet-300 text-xs">
                        {keyword}
                      </span>
                    ))}
                    {resume.keywords.length > 5 && (
                      <span className="px-2 py-0.5 bg-white/5 rounded text-gray-400 text-xs">
                        +{resume.keywords.length - 5} more
                      </span>
                    )}
                  </div>
                )}
              </motion.div>
            ))}

            {filteredResumes.length === 0 && (
              <div className="text-center py-8">
                <File className="mx-auto text-gray-600 mb-4" size={48} />
                <p className="text-gray-500">No resumes found</p>
              </div>
            )}
          </div>
        </GlassCard>

        {/* Cover Letter Templates */}
        <GlassCard delay={0.3}>
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <FileText className="text-cyan-400" size={20} /> Cover Letter Templates
          </h2>

          <div className="space-y-3 max-h-[450px] overflow-y-auto">
            {coverLetterTemplates.map((letter, index) => (
              <motion.div
                key={letter.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + index * 0.05 }}
                className="p-4 bg-glass rounded-xl border border-white/5 hover:border-cyan-500/30 transition-all group cursor-pointer"
                onClick={() => handleViewLetter(letter)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-medium">{letter.name}</h3>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => { e.stopPropagation(); handleCopyLetter(letter.fullText, letter.name); }}
                      className="text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      {copiedLetter === letter.name ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleCopyLetter(letter.fullText, letter.name); }}
                      className="text-gray-400 hover:text-cyan-400 transition-colors text-xs"
                    >
                      {copiedLetter === letter.name ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                </div>
                <p className="text-gray-500 text-sm line-clamp-2">{letter.preview}</p>
                <button
                  onClick={(e) => { e.stopPropagation(); handleViewLetter(letter); }}
                  className="mt-3 text-cyan-400 text-xs flex items-center gap-1 hover:underline"
                >
                  <Eye size={12} /> View Full Template
                </button>
              </motion.div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Keyword Score Tool */}
      <GlassCard delay={0.5}>
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <BarChart2 className="text-green-400" size={20} /> Check My Resume Keywords
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="text-gray-400 text-sm block mb-2">Paste Job Description Here</label>
            <textarea
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Copy and paste the job description to see how well your resume matches the keywords..."
              className="input-field w-full px-4 py-3 rounded-lg text-white resize-none"
              rows={10}
            />
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={calculateKeywordScore}
              className="btn-primary w-full mt-4 py-3 rounded-lg text-white font-semibold"
            >
              Check My Resume
            </motion.button>
          </div>

          <div className="flex items-center justify-center">
            {keywordScore ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center w-full"
              >
                <div className="relative w-40 h-40 mx-auto mb-6">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle cx="80" cy="80" r="70" stroke="#1a1a2e" strokeWidth="12" fill="none" />
                    <motion.circle
                      cx="80" cy="80" r="70"
                      stroke="url(#gradient)"
                      strokeWidth="12"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={`${keywordScore.score * 4.4} 440`}
                      initial={{ strokeDasharray: '0 440' }}
                      animate={{ strokeDasharray: `${keywordScore.score * 4.4} 440` }}
                      transition={{ duration: 1 }}
                    />
                    <defs>
                      <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#8A2BE2" />
                        <stop offset="100%" stopColor="#00FFFF" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-4xl font-bold gradient-text">{keywordScore.score}%</span>
                  </div>
                </div>

                <div className="space-y-4 text-left">
                  <div>
                    <p className="text-gray-400 text-sm mb-2 flex items-center gap-2">
                      <Check className="text-green-400" size={14} /> Found in your resume:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {keywordScore.found.slice(0, 10).map((keyword) => (
                        <span key={keyword} className="px-2 py-1 bg-green-500/20 rounded text-green-300 text-xs">
                          {keyword}
                        </span>
                      ))}
                    </div>
                  </div>

                  {keywordScore.missing.length > 0 && (
                    <div>
                      <p className="text-gray-400 text-sm mb-2 flex items-center gap-2">
                        <X className="text-red-400" size={14} /> Keywords to add:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {keywordScore.missing.map((keyword) => (
                          <span key={keyword} className="px-2 py-1 bg-red-500/20 rounded text-red-300 text-xs">
                            {keyword}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <div className="text-center">
                <Tag className="mx-auto text-gray-600 mb-4" size={48} />
                <p className="text-gray-500">Paste a job description to check your keyword match</p>
              </div>
            )}
          </div>
        </div>
      </GlassCard>

      {/* Add Resume Modal */}
      <AnimatePresence>
        {isResumeModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop"
            onClick={() => setIsResumeModalOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-glass border-glow rounded-2xl p-6 w-full max-w-lg card-glow max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Add New Resume</h2>
                <button onClick={() => setIsResumeModalOpen(false)} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm block mb-2">Resume Name *</label>
                  <input
                    type="text"
                    value={newResume.name}
                    onChange={(e) => setNewResume({ ...newResume, name: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                    placeholder="e.g., Frontend Developer Resume"
                  />
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Version</label>
                  <select
                    value={newResume.version}
                    onChange={(e) => setNewResume({ ...newResume, version: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                  >
                    <option value="v1">Version 1</option>
                    <option value="v2">Version 2</option>
                    <option value="v3">Version 3</option>
                  </select>
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Keywords (comma separated)</label>
                  <input
                    type="text"
                    value={newResume.keywords}
                    onChange={(e) => setNewResume({ ...newResume, keywords: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                    placeholder="e.g., React, TypeScript, Node.js"
                  />
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Resume Content</label>
                  <textarea
                    value={newResume.content}
                    onChange={(e) => setNewResume({ ...newResume, content: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white resize-none"
                    rows={6}
                    placeholder="Paste or type your resume content..."
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button onClick={() => setIsResumeModalOpen(false)} className="btn-secondary flex-1 py-3 rounded-lg text-white font-medium">
                    Cancel
                  </button>
                  <button onClick={handleAddResume} className="btn-primary flex-1 py-3 rounded-lg text-white font-medium">
                    Add Resume
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Resume Detail Modal */}
      <AnimatePresence>
        {isResumeDetailOpen && selectedResume && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop"
            onClick={() => setIsResumeDetailOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-glass border-glow rounded-2xl p-6 w-full max-w-2xl card-glow max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-white">{selectedResume.name}</h2>
                  <p className="text-gray-400 text-sm">{selectedResume.version} - {selectedResume.lastModified}</p>
                </div>
                <button onClick={() => setIsResumeDetailOpen(false)} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              {/* Keywords */}
              {selectedResume.keywords && selectedResume.keywords.length > 0 && (
                <div className="mb-6">
                  <h4 className="text-gray-400 text-sm mb-2">Keywords</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedResume.keywords.map((keyword) => (
                      <span key={keyword} className="px-3 py-1 bg-violet-500/20 rounded-lg text-violet-300 text-sm">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Content */}
              <div className="mb-6">
                <h4 className="text-gray-400 text-sm mb-2">Content Preview</h4>
                <div className="p-4 bg-glass rounded-lg border border-white/5 whitespace-pre-wrap text-white text-sm">
                  {selectedResume.content || 'No content available'}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <button
                  onClick={() => handleEditResume(selectedResume)}
                  className="btn-secondary flex-1 py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2"
                >
                  <Edit2 size={18} /> Edit
                </button>
                <button
                  onClick={() => handleDeleteResume(selectedResume.id)}
                  className="flex-1 py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2 bg-red-500/20 hover:bg-red-500/30 transition-colors"
                >
                  <Trash2 size={18} /> Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Resume Modal */}
      <AnimatePresence>
        {isEditResumeOpen && editResume && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop"
            onClick={() => setIsEditResumeOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-glass border-glow rounded-2xl p-6 w-full max-w-lg card-glow max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Edit Resume</h2>
                <button onClick={() => setIsEditResumeOpen(false)} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm block mb-2">Resume Name *</label>
                  <input
                    type="text"
                    value={editResume.name}
                    onChange={(e) => setEditResume({ ...editResume, name: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Keywords (comma separated)</label>
                  <input
                    type="text"
                    value={editResume.keywordsStr}
                    onChange={(e) => setEditResume({ ...editResume, keywordsStr: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Resume Content</label>
                  <textarea
                    value={editResume.content}
                    onChange={(e) => setEditResume({ ...editResume, content: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white resize-none"
                    rows={6}
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button onClick={() => setIsEditResumeOpen(false)} className="btn-secondary flex-1 py-3 rounded-lg text-white font-medium">
                    Cancel
                  </button>
                  <button onClick={handleSaveResume} className="btn-primary flex-1 py-3 rounded-lg text-white font-medium">
                    Save Changes
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Cover Letter View Modal */}
      <AnimatePresence>
        {isLetterModalOpen && selectedLetter && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop"
            onClick={() => setIsLetterModalOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-glass border-glow rounded-2xl p-6 w-full max-w-2xl card-glow max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-white">{selectedLetter.name}</h2>
                  <p className="text-gray-400 text-sm">Cover Letter Template</p>
                </div>
                <button onClick={() => setIsLetterModalOpen(false)} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <div className="p-4 bg-glass rounded-lg border border-white/5 whitespace-pre-wrap text-white text-sm mb-6">
                {selectedLetter.fullText}
              </div>

              <button
                onClick={() => { handleCopyLetter(selectedLetter.fullText, selectedLetter.name); }}
                className="btn-primary w-full py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2"
              >
                {copiedLetter === selectedLetter.name ? <Check size={18} /> : <Copy size={18} />}
                {copiedLetter === selectedLetter.name ? 'Copied!' : 'Copy to Clipboard'}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
