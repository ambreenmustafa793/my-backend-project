import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Link, DollarSign, Bell, ExternalLink, Sparkles, Briefcase, MapPin, Building2, Clock, X, Save, Plus, Trash2, RefreshCw } from 'lucide-react';
import GlassCard from '../components/GlassCard';

const mockJobData = {
  title: 'Senior Software Engineer',
  company: 'TechCorp',
  location: 'San Francisco, CA (Remote)',
  salary: { min: 150000, max: 200000 },
  posted: '2 days ago',
  description: 'Looking for an experienced software engineer...',
  requirements: ['React', 'TypeScript', 'Node.js', 'AWS']
};

const salaryRanges = [
  { title: 'Junior Developer', min: 60000, max: 90000, icon: '🌱' },
  { title: 'Mid Developer', min: 90000, max: 130000, icon: '💻' },
  { title: 'Senior Developer', min: 130000, max: 180000, icon: '🚀' },
  { title: 'Staff Engineer', min: 180000, max: 250000, icon: '⭐' },
  { title: 'Engineering Manager', min: 200000, max: 300000, icon: '👨‍💼' },
];

const savedJobs = [
  { id: '1', title: 'Full Stack Engineer', company: 'StartupXYZ', salary: '$120k-150k', location: 'Remote', dateAdded: 'Today' },
  { id: '2', title: 'Backend Developer', company: 'DataFlow', salary: '$140k-170k', location: 'Austin, TX', dateAdded: 'Yesterday' },
];

export default function JobScanner() {
  const [jobUrl, setJobUrl] = useState('');
  const [scannedJob, setScannedJob] = useState(null);
  const [isScanning, setIsScanning] = useState(false);
  const [dailyAlertsEnabled, setDailyAlertsEnabled] = useState(false);
  const [alertsEmail, setAlertsEmail] = useState('');
  const [savedJobsList, setSavedJobsList] = useState(savedJobs);
  const [keywords, setKeywords] = useState('');
  const [location, setLocation] = useState('');

  const handleScan = () => {
    if (!jobUrl.trim()) {
      alert('Please enter a job URL');
      return;
    }

    setIsScanning(true);

    // Simulate API call
    setTimeout(() => {
      setScannedJob({
        id: Date.now().toString(),
        ...mockJobData,
        url: jobUrl,
        salary: { min: 150000, max: 200000 }
      });
      setIsScanning(false);
    }, 1500);
  };

  const handleAddToJobs = () => {
    if (!scannedJob) return;

    const newJob = {
      id: Date.now().toString(),
      title: scannedJob.title,
      company: scannedJob.company,
      salary: `$${scannedJob.salary.min / 1000}k-$${scannedJob.salary.max / 1000}k`,
      location: scannedJob.location,
      dateAdded: 'Just now'
    };

    setSavedJobsList([newJob, ...savedJobsList]);
    alert(`Added "${scannedJob.title}" at ${scannedJob.company} to your saved jobs!`);
    setScannedJob(null);
    setJobUrl('');
  };

  const handleDeleteSavedJob = (id) => {
    if (confirm('Remove this job from saved?')) {
      setSavedJobsList(savedJobsList.filter((job) => job.id !== id));
    }
  };

  const clearScanner = () => {
    setScannedJob(null);
    setJobUrl('');
  };

  // Simulate job board search
  const handleSearchJobs = () => {
    alert(`Searching for jobs matching "${keywords}" in "${location}"...\n\nThis is a demo. In a real app, this would connect to job APIs like LinkedIn, Indeed, or Glassdoor.`);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto"
    >
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">Job Scanner</h1>
        <p className="text-gray-400">Quick-add jobs from any job posting URL</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="p-4 rounded-lg bg-violet-500/20 border-glow">
          <p className="text-gray-400 text-sm">Jobs Scanned</p>
          <p className="text-2xl font-bold text-white">23</p>
        </div>
        <div className="p-4 rounded-lg bg-cyan-500/20 border-glow">
          <p className="text-gray-400 text-sm">Added to Tracker</p>
          <p className="text-2xl font-bold text-white">{savedJobsList.length}</p>
        </div>
        <div className="p-4 rounded-lg bg-green-500/20 border-glow">
          <p className="text-gray-400 text-sm">Avg Salary Found</p>
          <p className="text-2xl font-bold text-white">$165k</p>
        </div>
        <div className="p-4 rounded-lg bg-yellow-500/20 border-glow">
          <p className="text-gray-400 text-sm">This Week</p>
          <p className="text-2xl font-bold text-white">7 scans</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* URL Scanner */}
        <GlassCard className="lg:col-span-2" delay={0.1}>
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Search className="text-violet-400" size={20} />
            Paste Job URL
          </h2>

          <div className="relative">
            <input
              type="url"
              value={jobUrl}
              onChange={(e) => setJobUrl(e.target.value)}
              placeholder="Paste LinkedIn, Indeed, or any job posting URL..."
              className="input-field w-full px-4 py-4 pl-12 rounded-xl text-white"
            />
            <Link className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleScan}
            disabled={isScanning || !jobUrl.trim()}
            className="btn-primary w-full mt-4 py-3 rounded-xl text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isScanning ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                >
                  <Sparkles size={20} />
                </motion.div>
                Scanning...
              </>
            ) : (
              <>
                <Search size={20} />
                Scan Job Posting
              </>
            )}
          </motion.button>

          {/* Scanned Job Result */}
          {scannedJob && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-6 bg-glass rounded-xl border border-violet-500/30"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-white">{scannedJob.title}</h3>
                  <div className="flex flex-wrap items-center gap-4 mt-2 text-gray-400 text-sm">
                    <span className="flex items-center gap-1">
                      <Building2 size={14} /> {scannedJob.company}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin size={14} /> {scannedJob.location}
                    </span>
                  </div>
                </div>
                <button
                  onClick={clearScanner}
                  className="text-gray-500 hover:text-white transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="p-4 bg-glass rounded-lg">
                  <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                    <DollarSign size={14} /> Estimated Salary
                  </div>
                  <p className="text-2xl font-bold gradient-text">
                    ${scannedJob.salary.min / 1000}k - ${scannedJob.salary.max / 1000}k
                  </p>
                </div>
                <div className="p-4 bg-glass rounded-lg">
                  <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                    <Clock size={14} /> Posted
                  </div>
                  <p className="text-lg font-bold text-white">{scannedJob.posted}</p>
                </div>
              </div>

              {scannedJob.requirements && (
                <div className="mb-4">
                  <p className="text-gray-400 text-sm mb-2">Requirements Detected:</p>
                  <div className="flex flex-wrap gap-2">
                    {scannedJob.requirements.map((req) => (
                      <span key={req} className="px-2 py-1 bg-violet-500/20 rounded text-violet-300 text-xs">
                        {req}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                <a
                  href={scannedJob.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary flex-1 py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2"
                >
                  <ExternalLink size={18} /> View Original
                </a>
                <button
                  onClick={handleAddToJobs}
                  className="btn-primary flex-1 py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2"
                >
                  <Plus size={18} /> Add to My Jobs
                </button>
              </div>
            </motion.div>
          )}

          {/* Saved Jobs List */}
          <div className="mt-6">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Briefcase className="text-violet-400" size={18} />
              Recently Added ({savedJobsList.length})
            </h3>
            <div className="space-y-2">
              {savedJobsList.map((job) => (
                <motion.div
                  key={job.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between p-3 bg-glass rounded-lg border border-white/5"
                >
                  <div className="flex items-center gap-3">
                    <Building2 className="text-violet-400" size={18} />
                    <div>
                      <p className="text-white text-sm font-medium">{job.title}</p>
                      <p className="text-gray-400 text-xs">{job.company} - {job.location}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-violet-400 text-sm">{job.salary}</span>
                    <button
                      onClick={() => handleDeleteSavedJob(job.id)}
                      className="text-gray-600 hover:text-red-400 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </GlassCard>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Quick Search */}
          <GlassCard delay={0.2}>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Search className="text-cyan-400" size={20} />
              Quick Search
            </h2>
            <div className="space-y-3">
              <div>
                <label className="text-gray-400 text-sm block mb-2">Keywords</label>
                <input
                  type="text"
                  value={keywords}
                  onChange={(e) => setKeywords(e.target.value)}
                  placeholder="e.g., React Developer"
                  className="input-field w-full px-3 py-2 rounded-lg text-white text-sm"
                />
              </div>
              <div>
                <label className="text-gray-400 text-sm block mb-2">Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g., Remote, San Francisco"
                  className="input-field w-full px-3 py-2 rounded-lg text-white text-sm"
                />
              </div>
              <button
                onClick={handleSearchJobs}
                className="btn-secondary w-full py-2 rounded-lg text-white text-sm flex items-center justify-center gap-2"
              >
                <Search size={16} /> Search Jobs
              </button>
            </div>
          </GlassCard>

          {/* Salary Estimator */}
          <GlassCard delay={0.3}>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <DollarSign className="text-green-400" size={20} />
              Salary Estimator
            </h2>
            <div className="space-y-3">
              {salaryRanges.map((range, index) => (
                <motion.div
                  key={range.title}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.05 }}
                  className="p-3 bg-glass rounded-lg"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white text-sm flex items-center gap-2">
                      <span>{range.icon}</span>
                      {range.title}
                    </span>
                    <span className="text-cyan-400 text-sm font-medium">
                      ${range.min / 1000}k - ${range.max / 1000}k
                    </span>
                  </div>
                  <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(range.max / 300000) * 100}%` }}
                      transition={{ duration: 0.8, delay: 0.5 + index * 0.05 }}
                      className="h-full gradient-bg rounded-full"
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Daily Alerts */}
          <GlassCard delay={0.5}>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Bell className="text-yellow-400" size={20} />
              Daily Job Alerts
            </h2>

            <div className="flex items-center justify-between p-4 bg-glass rounded-lg mb-4">
              <div>
                <p className="text-white font-medium">Enable Alerts</p>
                <p className="text-gray-500 text-sm">Get daily job recommendations</p>
              </div>
              <button
                onClick={() => setDailyAlertsEnabled(!dailyAlertsEnabled)}
                className={`w-14 h-8 rounded-full transition-all ${dailyAlertsEnabled ? 'bg-green-500' : 'bg-gray-700'}`}
              >
                <motion.div
                  animate={{ x: dailyAlertsEnabled ? 24 : 4 }}
                  className="w-6 h-6 bg-white rounded-full shadow-lg"
                />
              </button>
            </div>

            {dailyAlertsEnabled && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
              >
                <div className="mb-3">
                  <label className="text-gray-400 text-sm block mb-2">Send alerts to:</label>
                  <input
                    type="email"
                    value={alertsEmail}
                    onChange={(e) => setAlertsEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                  />
                </div>
                <div className="mb-3">
                  <label className="text-gray-400 text-sm block mb-2">Keywords to watch:</label>
                  <input
                    type="text"
                    placeholder="React, TypeScript, Remote..."
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                  />
                </div>
                <button className="btn-primary w-full py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2">
                  <Save size={18} /> Save Settings
                </button>
              </motion.div>
            )}

            <div className="mt-4 p-3 bg-violet-500/10 rounded-lg border border-violet-500/20">
              <p className="text-violet-300 text-xs">
                This is a demo feature. In a real app, this would connect to job search APIs.
              </p>
            </div>
          </GlassCard>
        </div>
      </div>
    </motion.div>
  );
}
