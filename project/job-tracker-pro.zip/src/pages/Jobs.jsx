import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, Building2, DollarSign, FileText, Trash2, GripVertical, Eye, Edit2, Calendar, MapPin, ExternalLink, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import GlassCard from '../components/GlassCard';

// Initial sample jobs data
const initialJobs = {
  applied: [
    { id: '1', company: 'TechCorp', title: 'Senior Developer', salary: '$120k-150k', notes: 'Applied via LinkedIn. Referred by Sarah.', location: 'San Francisco, CA', url: 'https://linkedin.com/jobs/1', dateApplied: '2 days ago', priority: 'high' },
    { id: '2', company: 'StartupXYZ', title: 'Full Stack Engineer', salary: '$100k-130k', notes: 'Found on AngelList. Interesting product.', location: 'Remote', url: 'https://angel.co/jobs/2', dateApplied: '5 days ago', priority: 'medium' },
    { id: '6', company: 'DataFlow Inc', title: 'Backend Developer', salary: '$110k-140k', notes: 'Python/Django stack', location: 'Austin, TX', url: '', dateApplied: '1 week ago', priority: 'low' },
  ],
  talking: [
    { id: '3', company: 'BigTech Inc', title: 'Staff Engineer', salary: '$180k-220k', notes: 'Phone screen scheduled for Thursday. Study system design!', location: 'Seattle, WA', url: 'https://bigtech.com/careers', dateApplied: '1 week ago', priority: 'high', nextStep: 'Phone screen Thursday 2PM' },
  ],
  offer: [
    { id: '4', company: 'InnovateLabs', title: 'Lead Developer', salary: '$160k', notes: 'Base $160k + $20k bonus + equity. Need to respond by Friday.', location: 'New York, NY', url: '', dateApplied: '2 weeks ago', priority: 'high', deadline: 'Friday' },
  ],
  not_moving: [
    { id: '5', company: 'OldCompany', title: 'Software Engineer', salary: '$90k', notes: 'Position was filled before I could apply.', location: 'Boston, MA', url: '', dateApplied: '3 weeks ago', priority: 'low', reason: 'Position filled' },
  ],
};

const columns = [
  { id: 'applied', title: 'Applied', color: 'border-violet-500', bgColor: 'bg-violet-500/20' },
  { id: 'talking', title: 'Talking to Them', color: 'border-cyan-500', bgColor: 'bg-cyan-500/20' },
  { id: 'offer', title: 'Got an Offer', color: 'border-green-500', bgColor: 'bg-green-500/20' },
  { id: 'not_moving', title: 'Not Moving Forward', color: 'border-red-500', bgColor: 'bg-red-500/20' },
];

export default function Jobs() {
  const [jobs, setJobs] = useState(initialJobs);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [draggedJob, setDraggedJob] = useState(null);
  const [newJob, setNewJob] = useState({
    company: '',
    title: '',
    salary: '',
    notes: '',
    status: 'applied',
    location: '',
    url: '',
    priority: 'medium'
  });
  const [editJob, setEditJob] = useState(null);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Add new job
  const handleAddJob = () => {
    if (!newJob.company || !newJob.title) {
      alert('Please fill in Company and Job Title');
      return;
    }

    const job = {
      id: Date.now().toString(),
      company: newJob.company,
      title: newJob.title,
      salary: newJob.salary,
      notes: newJob.notes,
      location: newJob.location,
      url: newJob.url,
      priority: newJob.priority,
      dateApplied: 'Just now',
    };

    setJobs((prev) => ({
      ...prev,
      [newJob.status]: [...prev[newJob.status], job],
    }));

    setNewJob({
      company: '',
      title: '',
      salary: '',
      notes: '',
      status: 'applied',
      location: '',
      url: '',
      priority: 'medium'
    });
    setIsModalOpen(false);
  };

  // Delete job
  const handleDeleteJob = (columnId, jobId) => {
    if (confirm('Are you sure you want to delete this job?')) {
      setJobs((prev) => ({
        ...prev,
        [columnId]: prev[columnId].filter((j) => j.id !== jobId),
      }));
      setIsDetailOpen(false);
      setSelectedJob(null);
    }
  };

  // Open job detail
  const handleViewJob = (job, columnId) => {
    setSelectedJob({ ...job, status: columnId });
    setIsDetailOpen(true);
  };

  // Open edit modal
  const handleEditJob = (job, columnId) => {
    setEditJob({ ...job, status: columnId });
    setIsEditModalOpen(true);
    setIsDetailOpen(false);
  };

  // Save edited job
  const handleSaveEdit = () => {
    if (!editJob.company || !editJob.title) {
      alert('Please fill in Company and Job Title');
      return;
    }

    const oldStatus = editJob.status;
    const newStatus = editJob.status;

    setJobs((prev) => {
      const updated = { ...prev };
      // Remove from old position
      updated[oldStatus] = updated[oldStatus].filter((j) => j.id !== editJob.id);
      // Add to new position (or same)
      updated[newStatus] = [...updated[newStatus], editJob];
      return updated;
    });

    setIsEditModalOpen(false);
    setEditJob(null);
  };

  // Drag and drop handlers
  const handleDragStart = (e, job, fromColumn) => {
    setDraggedJob({ job, fromColumn });
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, toColumn) => {
    e.preventDefault();
    if (!draggedJob) return;

    const { job, fromColumn } = draggedJob;
    if (fromColumn === toColumn) {
      setDraggedJob(null);
      return;
    }

    setJobs((prev) => ({
      ...prev,
      [fromColumn]: prev[fromColumn].filter((j) => j.id !== job.id),
      [toColumn]: [...prev[toColumn], job],
    }));

    setDraggedJob(null);
  };

  // Filter and search jobs
  const getAllJobs = () => {
    const allJobs = [];
    Object.keys(jobs).forEach((status) => {
      jobs[status].forEach((job) => {
        allJobs.push({ ...job, status });
      });
    });
    return allJobs;
  };

  const filteredJobs = getAllJobs().filter((job) => {
    const matchesSearch = job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.title.toLowerCase().includes(searchTerm.toLowerCase());
    if (filter === 'all') return matchesSearch;
    return job.priority === filter && matchesSearch;
  });

  // Move job to different status
  const moveJobToStatus = (job, newStatus) => {
    setJobs((prev) => ({
      ...prev,
      [job.status]: prev[job.status].filter((j) => j.id !== job.id),
      [newStatus]: [...prev[newStatus], { ...job, status: undefined }],
    }));
    setIsDetailOpen(false);
    setSelectedJob(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">My Jobs</h1>
          <p className="text-gray-400">Track and manage your job applications</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsModalOpen(true)}
          className="btn-primary px-6 py-3 rounded-xl text-white font-semibold flex items-center gap-2"
        >
          <Plus size={20} />
          Add a Job
        </motion.button>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by company or title..."
            className="input-field w-full px-4 py-3 rounded-lg text-white"
          />
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="input-field px-4 py-3 rounded-lg text-white"
        >
          <option value="all">All Priorities</option>
          <option value="high">High Priority</option>
          <option value="medium">Medium Priority</option>
          <option value="low">Low Priority</option>
        </select>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {columns.map((col) => (
          <div key={col.id} className={`p-4 rounded-lg ${col.bgColor} border-glow`}>
            <p className="text-gray-400 text-sm">{col.title}</p>
            <p className="text-2xl font-bold text-white">{jobs[col.id].length}</p>
          </div>
        ))}
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 lg:gap-6">
        {columns.map((column, colIndex) => (
          <motion.div
            key={column.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: colIndex * 0.1 }}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, column.id)}
            className="min-h-[300px]"
          >
            {/* Column Header */}
            <div className={`border-l-4 ${column.color} pl-4 mb-4 flex items-center justify-between`}>
              <div>
                <h3 className="text-white font-semibold">{column.title}</h3>
                <p className="text-gray-500 text-sm">{jobs[column.id].length} jobs</p>
              </div>
            </div>

            {/* Job Cards */}
            <div className="space-y-3 min-h-[200px]">
              <AnimatePresence>
                {jobs[column.id]
                  .filter((job) => {
                    const matchesSearch = job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      job.title.toLowerCase().includes(searchTerm.toLowerCase());
                    if (filter === 'all') return matchesSearch;
                    return job.priority === filter && matchesSearch;
                  })
                  .map((job, index) => (
                    <motion.div
                      key={job.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ delay: index * 0.05 }}
                      draggable
                      onDragStart={(e) => handleDragStart(e, job, column.id)}
                      className="kanban-card bg-glass border-glow rounded-xl p-4 cursor-grab active:cursor-grabbing group"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2 flex-1">
                          <GripVertical className="text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity" size={16} />
                          <div className={`w-2 h-2 rounded-full ${
                            job.priority === 'high' ? 'bg-red-500' :
                            job.priority === 'medium' ? 'bg-yellow-500' : 'bg-gray-500'
                          }`} />
                          <Building2 className="text-violet-400 flex-shrink-0" size={18} />
                          <h4 className="text-white font-medium truncate">{job.company}</h4>
                        </div>
                      </div>

                      <p className="text-gray-300 text-sm mb-2 pl-6">{job.title}</p>

                      <div className="flex items-center gap-3 text-xs text-gray-400 mb-3 pl-6">
                        {job.salary && (
                          <span className="flex items-center gap-1">
                            <DollarSign size={12} />
                            {job.salary}
                          </span>
                        )}
                        {job.location && (
                          <span className="flex items-center gap-1">
                            <MapPin size={12} />
                            {job.location.split(',')[0]}
                          </span>
                        )}
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                        <button
                          onClick={() => handleViewJob(job, column.id)}
                          className="flex-1 py-2 rounded-lg text-violet-400 text-xs flex items-center justify-center gap-1 hover:bg-violet-500/20 transition-colors"
                        >
                          <Eye size={14} /> View
                        </button>
                        <button
                          onClick={() => handleEditJob(job, column.id)}
                          className="flex-1 py-2 rounded-lg text-cyan-400 text-xs flex items-center justify-center gap-1 hover:bg-cyan-500/20 transition-colors"
                        >
                          <Edit2 size={14} /> Edit
                        </button>
                        <button
                          onClick={() => handleDeleteJob(column.id, job.id)}
                          className="flex-1 py-2 rounded-lg text-red-400 text-xs flex items-center justify-center gap-1 hover:bg-red-500/20 transition-colors"
                        >
                          <Trash2 size={14} /> Delete
                        </button>
                      </div>
                    </motion.div>
                  ))}
              </AnimatePresence>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add Job Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop"
            onClick={() => setIsModalOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-glass border-glow rounded-2xl p-6 w-full max-w-lg card-glow max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Add a Job</h2>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Company Name *</label>
                    <input
                      type="text"
                      value={newJob.company}
                      onChange={(e) => setNewJob({ ...newJob, company: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                      placeholder="e.g., TechCorp"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Job Title *</label>
                    <input
                      type="text"
                      value={newJob.title}
                      onChange={(e) => setNewJob({ ...newJob, title: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                      placeholder="e.g., Senior Developer"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Salary Range</label>
                    <input
                      type="text"
                      value={newJob.salary}
                      onChange={(e) => setNewJob({ ...newJob, salary: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                      placeholder="e.g., $120k-150k"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Location</label>
                    <input
                      type="text"
                      value={newJob.location}
                      onChange={(e) => setNewJob({ ...newJob, location: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                      placeholder="e.g., San Francisco, CA"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Status</label>
                    <select
                      value={newJob.status}
                      onChange={(e) => setNewJob({ ...newJob, status: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    >
                      <option value="applied">Applied</option>
                      <option value="talking">Talking to Them</option>
                      <option value="offer">Got an Offer</option>
                      <option value="not_moving">Not Moving Forward</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Priority</label>
                    <select
                      value={newJob.priority}
                      onChange={(e) => setNewJob({ ...newJob, priority: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    >
                      <option value="high">High</option>
                      <option value="medium">Medium</option>
                      <option value="low">Low</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Job Posting URL</label>
                  <input
                    type="url"
                    value={newJob.url}
                    onChange={(e) => setNewJob({ ...newJob, url: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                    placeholder="https://..."
                  />
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Notes</label>
                  <textarea
                    value={newJob.notes}
                    onChange={(e) => setNewJob({ ...newJob, notes: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white resize-none"
                    rows={3}
                    placeholder="Any additional notes..."
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setIsModalOpen(false)}
                    className="btn-secondary flex-1 py-3 rounded-lg text-white font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddJob}
                    className="btn-primary flex-1 py-3 rounded-lg text-white font-medium"
                  >
                    Add Job
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Job Detail Modal */}
      <AnimatePresence>
        {isDetailOpen && selectedJob && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop"
            onClick={() => setIsDetailOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-glass border-glow rounded-2xl p-6 w-full max-w-lg card-glow max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Job Details</h2>
                <button
                  onClick={() => setIsDetailOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-6">
                {/* Company and Title */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center">
                    <Building2 className="text-white" size={24} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white">{selectedJob.company}</h3>
                    <p className="text-gray-400">{selectedJob.title}</p>
                  </div>
                </div>

                {/* Status Badge */}
                <div className={`inline-block px-3 py-1 rounded-full text-sm ${
                  selectedJob.status === 'offer' ? 'bg-green-500/20 text-green-400' :
                  selectedJob.status === 'talking' ? 'bg-cyan-500/20 text-cyan-400' :
                  selectedJob.status === 'applied' ? 'bg-violet-500/20 text-violet-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {columns.find(c => c.id === selectedJob.status)?.title}
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-4">
                  {selectedJob.salary && (
                    <div className="p-4 bg-glass rounded-lg">
                      <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                        <DollarSign size={14} />
                        Salary
                      </div>
                      <p className="text-white font-semibold">{selectedJob.salary}</p>
                    </div>
                  )}
                  {selectedJob.location && (
                    <div className="p-4 bg-glass rounded-lg">
                      <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                        <MapPin size={14} />
                        Location
                      </div>
                      <p className="text-white font-semibold">{selectedJob.location}</p>
                    </div>
                  )}
                  <div className="p-4 bg-glass rounded-lg">
                    <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                      <Calendar size={14} />
                      Applied
                    </div>
                    <p className="text-white font-semibold">{selectedJob.dateApplied}</p>
                  </div>
                  <div className="p-4 bg-glass rounded-lg">
                    <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                      <AlertCircle size={14} />
                      Priority
                    </div>
                    <p className={`font-semibold ${
                      selectedJob.priority === 'high' ? 'text-red-400' :
                      selectedJob.priority === 'medium' ? 'text-yellow-400' : 'text-gray-400'
                    }`}>
                      {selectedJob.priority?.toUpperCase()}
                    </p>
                  </div>
                </div>

                {/* Notes */}
                {selectedJob.notes && (
                  <div>
                    <h4 className="text-gray-400 text-sm mb-2 flex items-center gap-2">
                      <FileText size={14} />
                      Notes
                    </h4>
                    <div className="p-4 bg-glass rounded-lg">
                      <p className="text-white">{selectedJob.notes}</p>
                    </div>
                  </div>
                )}

                {/* URL */}
                {selectedJob.url && (
                  <a
                    href={selectedJob.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 p-3 bg-violet-500/20 rounded-lg text-violet-400 hover:bg-violet-500/30 transition-colors"
                  >
                    <ExternalLink size={18} />
                    View Job Posting
                  </a>
                )}

                {/* Move Status Buttons */}
                <div>
                  <h4 className="text-gray-400 text-sm mb-3">Move to:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {columns.filter(c => c.id !== selectedJob.status).map((col) => (
                      <button
                        key={col.id}
                        onClick={() => moveJobToStatus(selectedJob, col.id)}
                        className={`p-2 rounded-lg ${col.bgColor} text-white text-sm hover:opacity-80 transition-opacity`}
                      >
                        {col.title}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => handleEditJob(selectedJob, selectedJob.status)}
                    className="btn-secondary flex-1 py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2"
                  >
                    <Edit2 size={18} /> Edit
                  </button>
                  <button
                    onClick={() => handleDeleteJob(selectedJob.status, selectedJob.id)}
                    className="flex-1 py-3 rounded-lg text-white font-medium flex items-center justify-center gap-2 bg-red-500/20 hover:bg-red-500/30 transition-colors"
                  >
                    <Trash2 size={18} /> Delete
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Job Modal */}
      <AnimatePresence>
        {isEditModalOpen && editJob && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop"
            onClick={() => setIsEditModalOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-glass border-glow rounded-2xl p-6 w-full max-w-lg card-glow max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Edit Job</h2>
                <button
                  onClick={() => setIsEditModalOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Company Name *</label>
                    <input
                      type="text"
                      value={editJob.company}
                      onChange={(e) => setEditJob({ ...editJob, company: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Job Title *</label>
                    <input
                      type="text"
                      value={editJob.title}
                      onChange={(e) => setEditJob({ ...editJob, title: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Salary Range</label>
                    <input
                      type="text"
                      value={editJob.salary}
                      onChange={(e) => setEditJob({ ...editJob, salary: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Location</label>
                    <input
                      type="text"
                      value={editJob.location}
                      onChange={(e) => setEditJob({ ...editJob, location: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Status</label>
                    <select
                      value={editJob.status}
                      onChange={(e) => setEditJob({ ...editJob, status: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    >
                      <option value="applied">Applied</option>
                      <option value="talking">Talking to Them</option>
                      <option value="offer">Got an Offer</option>
                      <option value="not_moving">Not Moving Forward</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm block mb-2">Priority</label>
                    <select
                      value={editJob.priority}
                      onChange={(e) => setEditJob({ ...editJob, priority: e.target.value })}
                      className="input-field w-full px-4 py-3 rounded-lg text-white"
                    >
                      <option value="high">High</option>
                      <option value="medium">Medium</option>
                      <option value="low">Low</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Job Posting URL</label>
                  <input
                    type="url"
                    value={editJob.url}
                    onChange={(e) => setEditJob({ ...editJob, url: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="text-gray-400 text-sm block mb-2">Notes</label>
                  <textarea
                    value={editJob.notes}
                    onChange={(e) => setEditJob({ ...editJob, notes: e.target.value })}
                    className="input-field w-full px-4 py-3 rounded-lg text-white resize-none"
                    rows={4}
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setIsEditModalOpen(false)}
                    className="btn-secondary flex-1 py-3 rounded-lg text-white font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveEdit}
                    className="btn-primary flex-1 py-3 rounded-lg text-white font-medium"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Drag hint */}
      <p className="text-center text-gray-500 text-sm mt-6">
        Drag and drop cards between columns to update status
      </p>
    </motion.div>
  );
}
