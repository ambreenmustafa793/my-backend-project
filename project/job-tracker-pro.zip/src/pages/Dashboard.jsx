import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Briefcase, MessageCircle, Award, XCircle, TrendingUp, Clock, Target, Sparkles, Calendar, Bell, ChevronRight } from 'lucide-react';
import GlassCard from '../components/GlassCard';

const stats = [
  { label: 'Jobs Applied', value: 24, icon: Briefcase, color: 'from-violet-500 to-purple-600', change: '+5 this week' },
  { label: 'Talking to Them', value: 8, icon: MessageCircle, color: 'from-cyan-500 to-blue-600', change: '+2 this week' },
  { label: 'Got an Offer', value: 2, icon: Award, color: 'from-green-500 to-emerald-600', change: '1 new!' },
  { label: 'Not Moving Forward', value: 5, icon: XCircle, color: 'from-red-500 to-rose-600', change: 'That is okay!' },
];

const recentActivity = [
  { action: 'Applied to Senior Developer at TechCorp', time: '2 hours ago', type: 'applied', details: 'Via LinkedIn Easy Apply' },
  { action: 'Got a reply from StartupXYZ', time: '5 hours ago', type: 'reply', details: 'They want to schedule a call' },
  { action: 'Interview scheduled with BigTech', time: 'Yesterday', type: 'interview', details: 'Thursday at 2 PM' },
  { action: 'Offer received from InnovateLabs', time: '2 days ago', type: 'offer', details: '$160k + equity' },
  { action: 'Application viewed by Google', time: '3 days ago', type: 'viewed', details: 'Your profile caught attention' },
];

const upcomingTasks = [
  { task: 'Prepare for BigTech interview', date: 'Thursday 2 PM', urgent: true },
  { task: 'Send follow-up to StartupXYZ', date: 'Tomorrow', urgent: false },
  { task: 'Update resume with new skills', date: 'This week', urgent: false },
  { task: 'Respond to InnovateLabs offer', date: 'By Friday', urgent: true },
];

const tips = [
  'Follow up within 48 hours after an interview',
  'Customize your resume for each application',
  'Connect with employees at target companies',
  'Practice your elevator pitch daily',
  'Research the company before interviews',
  'Send a thank you email after every interview',
];

function AnimatedNumber({ value }) {
  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, type: 'spring' }}
      className="stat-number gradient-text"
    >
      {value}
    </motion.span>
  );
}

export default function Dashboard() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto"
    >
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">My Dashboard</h1>
        <p className="text-gray-400">Track your job search progress at a glance</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
        {stats.map((stat, index) => (
          <GlassCard key={stat.label} delay={index * 0.1}>
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color}`}>
                <stat.icon size={24} className="text-white" />
              </div>
              <TrendingUp className="text-green-400" size={20} />
            </div>
            <AnimatedNumber value={stat.value} />
            <p className="text-gray-400 mt-2">{stat.label}</p>
            <p className="text-violet-400 text-sm mt-1">{stat.change}</p>
          </GlassCard>
        ))}
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <GlassCard className="lg:col-span-2" delay={0.4}>
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Clock className="text-violet-400" size={20} />
            Recent Activity
          </h2>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="flex items-center gap-4 p-4 bg-glass rounded-lg border border-white/5 hover:border-violet-500/30 transition-all cursor-pointer"
              >
                <div className={`w-3 h-3 rounded-full ${
                  activity.type === 'offer' ? 'bg-green-500' :
                  activity.type === 'interview' ? 'bg-cyan-500' :
                  activity.type === 'reply' ? 'bg-blue-500' : 'bg-violet-500'
                }`} />
                <div className="flex-1">
                  <p className="text-white text-sm font-medium">{activity.action}</p>
                  <p className="text-gray-400 text-xs">{activity.details}</p>
                </div>
                <div className="text-right">
                  <p className="text-gray-500 text-xs">{activity.time}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Upcoming Tasks */}
          <GlassCard delay={0.5}>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Calendar className="text-cyan-400" size={20} />
              Upcoming Tasks
            </h2>
            <div className="space-y-3">
              {upcomingTasks.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  className={`p-3 rounded-lg border ${item.urgent ? 'border-red-500/50 bg-red-500/10' : 'border-white/5 bg-glass'}`}
                >
                  <div className="flex items-center justify-between">
                    <p className="text-white text-sm font-medium">{item.task}</p>
                    {item.urgent && <span className="text-red-400 text-xs">Urgent</span>}
                  </div>
                  <p className="text-gray-400 text-xs mt-1">{item.date}</p>
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Quick Tips */}
          <GlassCard delay={0.6}>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Sparkles className="text-yellow-400" size={20} />
              Quick Tips
            </h2>
            <div className="space-y-3">
              {tips.slice(0, 4).map((tip, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-start gap-3 p-3 bg-glass rounded-lg"
                >
                  <Target className="text-violet-400 flex-shrink-0 mt-0.5" size={16} />
                  <p className="text-gray-300 text-sm">{tip}</p>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Progress Bar */}
      <GlassCard className="mt-6" delay={0.8}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-white font-semibold">Monthly Goal Progress</h3>
          <span className="text-violet-400 font-bold">75%</span>
        </div>
        <div className="h-3 bg-gray-800 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: '75%' }}
            transition={{ duration: 1, delay: 1 }}
            className="h-full gradient-bg rounded-full"
          />
        </div>
        <p className="text-gray-500 text-sm mt-2">Applied to 15 of 20 target jobs this month</p>
      </GlassCard>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <Link to="/jobs">
          <GlassCard delay={0.9} className="cursor-pointer hover:border-violet-500/50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-semibold">Add New Job</h3>
                <p className="text-gray-400 text-sm">Track a new application</p>
              </div>
              <ChevronRight className="text-violet-400" size={24} />
            </div>
          </GlassCard>
        </Link>

        <Link to="/prep">
          <GlassCard delay={1.0} className="cursor-pointer hover:border-cyan-500/50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-semibold">Practice Interview</h3>
                <p className="text-gray-400 text-sm">Prepare for interviews</p>
              </div>
              <ChevronRight className="text-cyan-400" size={24} />
            </div>
          </GlassCard>
        </Link>

        <Link to="/scanner">
          <GlassCard delay={1.1} className="cursor-pointer hover:border-green-500/50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-semibold">Scan Job URL</h3>
                <p className="text-gray-400 text-sm">Quick add from posting</p>
              </div>
              <ChevronRight className="text-green-400" size={24} />
            </div>
          </GlassCard>
        </Link>
      </div>
    </motion.div>
  );
}
